import { requireAuth, updateSiteConfig, logEvent, logout } from "./db.js";
import {
  qs,
  qsa,
  applyTheme,
  applyImages,
  applyLayout,
  renderHudPanels
} from "./common.js";

let isEditMode = false;
let dragTarget = null;
let startX = 0;
let startY = 0;
let startDX = 0;
let startDY = 0;
let currentUser = null;
let currentConfig = null;

const isAdminRole = (role) => role === "Owner" || role === "Admin";

function toggleEditMode(enabled) {
  isEditMode = enabled;
  document.body.classList.toggle("edit-mode", enabled);
}

function attachDragHandlers() {
  document.addEventListener("pointerdown", (e) => {
    if (!isEditMode) return;
    const target = e.target.closest("[data-editable]");
    if (!target) return;
    dragTarget = target;
    startX = e.clientX;
    startY = e.clientY;
    startDX = parseFloat(target.dataset.dx || "0");
    startDY = parseFloat(target.dataset.dy || "0");
    target.setPointerCapture(e.pointerId);
  });

  document.addEventListener("pointermove", (e) => {
    if (!dragTarget) return;
    const dx = startDX + (e.clientX - startX);
    const dy = startDY + (e.clientY - startY);
    dragTarget.dataset.dx = dx.toFixed(0);
    dragTarget.dataset.dy = dy.toFixed(0);
    dragTarget.style.transform = `translate(${dx}px, ${dy}px)`;
  });

  document.addEventListener("pointerup", (e) => {
    if (!dragTarget) return;
    dragTarget.releasePointerCapture(e.pointerId);
    const editId = dragTarget.getAttribute("data-edit-id");
    const layoutPatch = {
      [editId]: {
        dx: parseFloat(dragTarget.dataset.dx || "0"),
        dy: parseFloat(dragTarget.dataset.dy || "0")
      }
    };
    updateSiteConfig({ layout: layoutPatch }).then((config) => {
      if (!config) return;
      currentConfig = config;
      applyLayout(config.layout);
      logEvent("layout-change", editId);
    });
    dragTarget = null;
  });

  document.addEventListener("click", (e) => {
    if (!isEditMode) return;
    const link = e.target.closest("a");
    if (link && link.hasAttribute("data-editable")) {
      e.preventDefault();
    }
  });
}

function initAdminPanel(config) {
  const panel = qs("[data-admin-panel]");
  if (!panel) return;
  panel.style.display = "block";

  const editToggle = qs("#edit-toggle");
  if (editToggle) {
    editToggle.addEventListener("change", (e) => {
      toggleEditMode(e.target.checked);
      logEvent("edit-mode", e.target.checked ? "on" : "off");
    });
  }

  const accentInput = qs("#accent-color");
  const accentSoftInput = qs("#accent-soft-color");
  const fontSelect = qs("#font-select");

  if (accentInput) accentInput.value = config.theme?.accent || "#d7b76a";
  if (accentSoftInput) accentSoftInput.value = config.theme?.accentSoft || "#6ec7b3";
  if (fontSelect) fontSelect.value = config.theme?.font || "Oxanium";

  accentInput?.addEventListener("input", async (e) => {
    const updated = await updateSiteConfig({ theme: { accent: e.target.value } });
    if (!updated) return;
    currentConfig = updated;
    applyTheme(updated.theme);
    logEvent("theme-change", "accent");
  });

  accentSoftInput?.addEventListener("input", async (e) => {
    const updated = await updateSiteConfig({ theme: { accentSoft: e.target.value } });
    if (!updated) return;
    currentConfig = updated;
    applyTheme(updated.theme);
    logEvent("theme-change", "accentSoft");
  });

  fontSelect?.addEventListener("change", async (e) => {
    const updated = await updateSiteConfig({ theme: { font: e.target.value } });
    if (!updated) return;
    currentConfig = updated;
    applyTheme(updated.theme);
    logEvent("theme-change", "font");
  });

  const imageTarget = qs("#image-target");
  const imageFile = qs("#image-file");
  const imageApply = qs("#image-apply");

  imageApply?.addEventListener("click", async () => {
    if (!imageFile?.files?.length) return;
    const targetKey = imageTarget.value;
    const file = imageFile.files[0];
    const reader = new FileReader();
    reader.onload = async () => {
      const updated = await updateSiteConfig({ images: { [targetKey]: reader.result } });
      if (!updated) return;
      currentConfig = updated;
      applyImages(updated.images);
      logEvent("image-upload", targetKey);
    };
    reader.readAsDataURL(file);
  });

  const hudTitle = qs("#hud-title");
  const hudContent = qs("#hud-content");
  const hudAdd = qs("#hud-add");

  hudAdd?.addEventListener("click", async () => {
    const newPanel = {
      id: `hud-${Date.now()}`,
      title: hudTitle.value || "HUD Panel",
      content: hudContent.value || "تفاصيل اللوحة الجديدة",
      x: 60,
      y: 140
    };
    const existing = currentConfig?.hudPanels || [];
    const nextPanels = [...existing, newPanel];
    const updated = await updateSiteConfig({ hudPanels: nextPanels });
    if (!updated) return;
    currentConfig = updated;
    renderHudPanels(updated.hudPanels);
    logEvent("hud-add", newPanel.id);
  });
}

function initGeneralUI() {
  const settingsBtn = qs("[data-action='settings']");
  const settingsPanel = qs("[data-settings-panel]");
  settingsBtn?.addEventListener("click", () => {
    settingsPanel?.classList.toggle("active");
    if (currentUser) {
      logEvent("toggle", "settings-panel");
    }
  });

  const langBtn = qs("[data-action='lang']");
  langBtn?.addEventListener("click", () => {
    const html = document.documentElement;
    const newDir = html.getAttribute("dir") === "rtl" ? "ltr" : "rtl";
    html.setAttribute("dir", newDir);
    if (currentUser) {
      logEvent("toggle", `lang:${newDir}`);
    }
  });

  const logoutBtn = qs("[data-action='logout']");
  logoutBtn?.addEventListener("click", async () => {
    if (currentUser) {
      logEvent("logout", "user logout");
    }
    await logout();
    window.location.href = "index.html";
  });
}

async function init() {
  const auth = await requireAuth();
  if (!auth) return;
  currentUser = auth.user;
  currentConfig = auth.siteConfig || { theme: {}, images: {}, layout: {}, hudPanels: [] };

  initGeneralUI();

  if (isAdminRole(currentUser.role)) {
    initAdminPanel(currentConfig);
  } else {
    const panel = qs("[data-admin-panel]");
    if (panel) panel.remove();
  }

  applyTheme(currentConfig.theme);
  applyImages(currentConfig.images);
  renderHudPanels(currentConfig.hudPanels);
  applyLayout(currentConfig.layout);

  attachDragHandlers();
}

init();
