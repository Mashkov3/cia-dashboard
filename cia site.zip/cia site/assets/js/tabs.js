export const TABS = [
  {
    id: "encryption",
    label: "قسم التشفير",
    subtitle: "تأمين الاتصالات الحيوية",
    summary: "لوحة إدارة المفاتيح والتحقق من القنوات الآمنة.",
    path: "encryption.html"
  },
  {
    id: "blackbox",
    label: "الصندوق الأسود",
    subtitle: "الأرشفة الحساسة",
    summary: "تتبع الأدلة السرية والمصادر عالية التصنيف.",
    path: "blackbox.html"
  },
  {
    id: "reports",
    label: "قسم التقارير",
    subtitle: "تجميع وتحليل",
    summary: "تحضير التقارير اليومية والاستنتاجات الميدانية.",
    path: "reports.html"
  },
  {
    id: "ops-maps",
    label: "خرائط العمليات",
    subtitle: "نقاط السيطرة",
    summary: "عرض الخرائط التكتيكية والتحركات المباشرة.",
    path: "ops-maps.html"
  },
  {
    id: "leadership-notes",
    label: "ملاحظات القيادة",
    subtitle: "اتجاهات استراتيجية",
    summary: "إشعارات القيادة والقرارات العاجلة.",
    path: "leadership-notes.html"
  },
  {
    id: "tasks-points",
    label: "قسم المهام و النقاط",
    subtitle: "تنسيق المهام",
    summary: "تنظيم المهام الميدانية ومؤشرات التنفيذ.",
    path: "tasks-points.html"
  },
  {
    id: "saved-reports",
    label: "التقارير المحفوظة",
    subtitle: "الأرشيف العملياتي",
    summary: "الوصول السريع للتقارير المصنفة.",
    path: "saved-reports.html"
  },
  {
    id: "wanted",
    label: "المطلوبين",
    subtitle: "قائمة الملاحقة",
    summary: "متابعة الأهداف ذات الأولوية العالية.",
    path: "wanted.html"
  },
  {
    id: "video",
    label: "قسم الفيديو",
    subtitle: "مراقبة متعددة",
    summary: "إدارة بث الفيديو واللقطات الحية.",
    path: "video.html"
  },
  {
    id: "gangs",
    label: "قسم العصابات",
    subtitle: "شبكات النشاط",
    summary: "خرائط المجموعات وتتبع التحركات.",
    path: "gangs.html"
  },
  {
    id: "officials",
    label: "المسؤولين",
    subtitle: "الجهات المعتمدة",
    summary: "ملفات المسؤولين وقنوات الاتصال الرسمية.",
    path: "officials.html"
  }
];
