import { requireAuth, logEvent } from "./db.js";
import { TABS } from "./tabs.js";
import { qs, applyTheme, applyImages, applyLayout, renderHudPanels, getQueryParam, setPageTitle } from "./common.js";

async function init() {
  const auth = await requireAuth();
  if (!auth) return;
  const { user, siteConfig: rawConfig } = auth;
  const siteConfig = rawConfig || { theme: {}, images: {}, layout: {}, hudPanels: [] };
  const tabId = getQueryParam("tab");
  const tab = TABS.find((t) => t.id === tabId) || TABS[0];

  const usernameEl = qs("[data-username]");
  if (usernameEl) usernameEl.textContent = user.username;

  const title = tab ? tab.label : "تبويبة";
  setPageTitle(title);

  const content = qs("[data-tab-content]");
  if (content) {
    content.innerHTML = `
      <div class="section-label">لوحة التبويبة</div>
      <h2>${title}</h2>
      <p class="muted">هنا تضع محتوى التبويبة الخاصة بك. يمكنك إضافة أقسام، جداول، أو لوحات HUD حسب الحاجة.</p>
    `;
  }

  applyTheme(siteConfig.theme);
  applyImages(siteConfig.images);
  renderHudPanels(siteConfig.hudPanels);
  applyLayout(siteConfig.layout);

  logEvent("view", `tab:${tabId || "default"}`);
}

init();
