export const qs = (sel, ctx = document) => ctx.querySelector(sel);
export const qsa = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

export function applyTheme(theme = {}) {
  const root = document.documentElement;
  if (theme.accent) root.style.setProperty("--accent", theme.accent);
  if (theme.accentSoft) root.style.setProperty("--accent-soft", theme.accentSoft);
  if (theme.panel) root.style.setProperty("--panel", theme.panel);
  if (theme.text) root.style.setProperty("--text", theme.text);
  if (theme.font) root.style.setProperty("--font-main", `"${theme.font}", "Rajdhani", "Segoe UI", sans-serif`);
}

export function applyImages(images = {}) {
  qsa("[data-image-target]").forEach((el) => {
    const key = el.getAttribute("data-image-target");
    if (!images[key]) return;
    if (el.tagName.toLowerCase() === "img") {
      el.src = images[key];
    } else {
      el.style.backgroundImage = `url(${images[key]})`;
      el.style.backgroundSize = "cover";
      el.style.backgroundPosition = "center";
    }
  });
}

export function applyLayout(layout = {}) {
  qsa("[data-edit-id]").forEach((el) => {
    const key = el.getAttribute("data-edit-id");
    const pos = layout[key];
    if (!pos) return;
    el.dataset.dx = pos.dx || 0;
    el.dataset.dy = pos.dy || 0;
    el.style.transform = `translate(${pos.dx || 0}px, ${pos.dy || 0}px)`;
  });
}

export function renderHudPanels(panels = []) {
  const container = qs("[data-hud-container]");
  if (!container) return;
  container.innerHTML = "";
  panels.forEach((panel) => {
    const el = document.createElement("div");
    el.className = "hud-panel";
    el.setAttribute("data-editable", "true");
    el.setAttribute("data-edit-id", panel.id);
    el.style.left = `${panel.x || 40}px`;
    el.style.top = `${panel.y || 120}px`;
    el.innerHTML = `<strong>${panel.title}</strong><div class="muted">${panel.content}</div>`;
    container.appendChild(el);
  });
}

export function getQueryParam(key) {
  const params = new URLSearchParams(window.location.search);
  return params.get(key);
}

export function setPageTitle(text) {
  const titleEl = qs("[data-page-title]");
  if (titleEl) titleEl.textContent = text;
  document.title = text;
}
