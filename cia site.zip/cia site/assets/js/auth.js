import { login, register } from "./db.js";

const loginForm = document.querySelector("#login-form");
const registerForm = document.querySelector("#register-form");

if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = loginForm.username.value.trim();
    const password = loginForm.password.value.trim();
    const errorBox = document.querySelector("#login-error");
    errorBox.textContent = "";

    if (!username || !password) {
      errorBox.textContent = "الرجاء إدخال الاسم وكلمة المرور.";
      return;
    }
    const result = await login(username, password);
    if (!result.ok) {
      errorBox.textContent = result.error || "بيانات الدخول غير صحيحة.";
      return;
    }
    window.location.href = "app.html";
  });
}

if (registerForm) {
  registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = registerForm.username.value.trim();
    const password = registerForm.password.value.trim();
    const errorBox = document.querySelector("#register-error");
    errorBox.textContent = "";

    if (!username || !password) {
      errorBox.textContent = "الرجاء إدخال الاسم وكلمة المرور.";
      return;
    }
    const result = await register(username, password);
    if (!result.ok) {
      errorBox.textContent = result.error || "تعذر إنشاء الحساب.";
      return;
    }
    window.location.href = "index.html";
  });
}
