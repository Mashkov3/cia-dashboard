import { requireAuth, logEvent } from "./db.js";
import { TABS } from "./tabs.js";
import { qs, applyTheme, applyImages, applyLayout, renderHudPanels, setPageTitle } from "./common.js";

const HOME_TITLE = "منظومة السلك الفدرالي";

async function init() {
  const auth = await requireAuth();
  if (!auth) return;
  const { user, siteConfig: rawConfig } = auth;
  const siteConfig = rawConfig || { theme: {}, images: {}, layout: {}, hudPanels: [] };

  const usernameEl = qs("[data-username]");
  if (usernameEl) usernameEl.textContent = user.username;

  setPageTitle(HOME_TITLE);

  const tabsWrap = qs("[data-tabs]");
  if (tabsWrap) {
    tabsWrap.innerHTML = "";
    TABS.forEach((tab) => {
      const link = document.createElement("a");
      link.className = "tab-card";
      link.href = tab.path || `tab.html?tab=${encodeURIComponent(tab.id)}`;
      link.setAttribute("data-editable", "true");
      link.setAttribute("data-edit-id", `tab-${tab.id}`);
      link.innerHTML = `
        <div class="tab-label">${tab.label}</div>
        <div class="tab-sub">${tab.subtitle || ""}</div>
      `;
      link.addEventListener("click", () => {
        logEvent("navigate", `tab:${tab.id}`);
      });
      tabsWrap.appendChild(link);
    });
  }

  applyTheme(siteConfig.theme);
  applyImages(siteConfig.images);
  renderHudPanels(siteConfig.hudPanels);
  applyLayout(siteConfig.layout);

  logEvent("view", "home");
}

init();
