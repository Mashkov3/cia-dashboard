const API_BASE = "";

async function request(path, options = {}) {
  const { method = "GET", body } = options;
  try {
    const res = await fetch(`${API_BASE}${path}`, {
      method,
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      credentials: "include"
    });
    let data = {};
    try {
      data = await res.json();
    } catch (err) {
      data = {};
    }
    if (!res.ok) {
      return { ok: false, error: data.error || "حدث خطأ غير متوقع." };
    }
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: "تعذر الاتصال بالخادم." };
  }
}

export async function login(username, password) {
  return request("/api/login", {
    method: "POST",
    body: { username, password }
  });
}

export async function register(username, password) {
  return request("/api/register", {
    method: "POST",
    body: { username, password }
  });
}

export async function logout() {
  return request("/api/logout", { method: "POST" });
}

export async function getBootstrap() {
  return request("/api/bootstrap");
}

export async function requireAuth() {
  const result = await getBootstrap();
  if (!result.ok) {
    window.location.href = "index.html";
    return null;
  }
  return result.data;
}

export async function logEvent(action, detail) {
  await request("/api/log", {
    method: "POST",
    body: { action, detail }
  });
}

export async function updateSiteConfig(patch) {
  const result = await request("/api/config", {
    method: "POST",
    body: { patch }
  });
  return result.ok ? result.data : null;
}
