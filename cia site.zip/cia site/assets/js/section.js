import { requireAuth, logEvent } from "./db.js";
import { TABS } from "./tabs.js";
import {
  qs,
  applyTheme,
  applyImages,
  applyLayout,
  renderHudPanels,
  setPageTitle
} from "./common.js";

const fallbackConfig = { theme: {}, images: {}, layout: {}, hudPanels: [] };

function getTabByPage(tabId) {
  if (tabId) return TABS.find((t) => t.id === tabId);
  const current = window.location.pathname.split("/").pop();
  return TABS.find((t) => t.path === current);
}

function renderTabs(activeId) {
  const wrap = qs("[data-section-tabs]");
  if (!wrap) return;
  wrap.innerHTML = "";
  TABS.forEach((tab) => {
    const link = document.createElement("a");
    link.className = `tab-button${tab.id === activeId ? " active" : ""}`;
    link.href = tab.path || `tab.html?tab=${encodeURIComponent(tab.id)}`;
    link.setAttribute("data-editable", "true");
    link.setAttribute("data-edit-id", `tab-${tab.id}`);
    link.textContent = tab.label;
    link.addEventListener("click", () => {
      logEvent("navigate", `section:${tab.id}`);
    });
    wrap.appendChild(link);
  });
}

function renderContent(tab) {
  const content = qs("[data-section-content]");
  if (!content || !tab) return;
  content.innerHTML = `
    <div class="section-label">مركز العمليات</div>
    <h2>${tab.label}</h2>
    <p class="muted">${tab.summary || "مساحة مخصصة لبيانات هذه التبويبة."}</p>
  `;
}

async function init() {
  const auth = await requireAuth();
  if (!auth) return;
  const { user, siteConfig: rawConfig } = auth;
  const siteConfig = rawConfig || fallbackConfig;

  const usernameEl = qs("[data-username]");
  if (usernameEl) usernameEl.textContent = user.username;

  const tabId = document.body.dataset.tabId;
  const tab = getTabByPage(tabId) || TABS[0];

  setPageTitle(tab.label);
  const titleEl = qs("[data-section-title]");
  if (titleEl) titleEl.textContent = tab.label;

  renderTabs(tab.id);
  renderContent(tab);

  applyTheme(siteConfig.theme);
  applyImages(siteConfig.images);
  renderHudPanels(siteConfig.hudPanels);
  applyLayout(siteConfig.layout);

  logEvent("view", `section:${tab.id}`);
}

init();
