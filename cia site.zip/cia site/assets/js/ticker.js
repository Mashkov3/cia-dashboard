const messages = [
  "تم تفعيل البروتوكول الفدرالي رقم 7",
  "مراقبة الاتصالات المشفرة قيد التشغيل",
  "تحديثات الأنظمة الحيوية جارية الآن",
  "جاهزية الاستجابة الفورية بنسبة 98%"
];

let index = 0;
const textEl = document.querySelector("[data-ticker-text]");

if (textEl) {
  textEl.textContent = messages[index];
  textEl.addEventListener("animationiteration", () => {
    index = (index + 1) % messages.length;
    textEl.textContent = messages[index];
  });
}
