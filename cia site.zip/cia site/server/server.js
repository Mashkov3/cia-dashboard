const path = require("path");
const fs = require("fs");
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const sqlite3 = require("sqlite3").verbose();

const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, "..");
const DB_PATH = path.join(__dirname, "database.sqlite");
const SEED_PATH = path.join(ROOT, "data", "database.json");

const app = express();
const db = new sqlite3.Database(DB_PATH);

const run = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });

const get = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });

const all = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });

const DEFAULT_CONFIG = {
  theme: {
    accent: "#d7b76a",
    accentSoft: "#6ec7b3",
    panel: "#122235",
    text: "#e9f1f6",
    font: "Oxanium"
  },
  layout: {},
  images: {
    logo: "",
    tickerLogo: ""
  },
  hudPanels: []
};

async function initDb() {
  await run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL,
      created_at TEXT NOT NULL,
      last_login_at TEXT
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      ts TEXT NOT NULL,
      action TEXT NOT NULL,
      detail TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS site_config (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      json TEXT NOT NULL
    )
  `);

  const countRow = await get("SELECT COUNT(*) as count FROM users");
  const hasUsers = countRow && countRow.count > 0;

  if (!hasUsers) {
    let seed = null;
    if (fs.existsSync(SEED_PATH)) {
      try {
        seed = JSON.parse(fs.readFileSync(SEED_PATH, "utf8"));
      } catch (err) {
        seed = null;
      }
    }

    const seedUsers = seed?.users?.length ? seed.users : [
      { username: "Director", password: "director-001", role: "Owner" },
      { username: "Control", password: "admin-001", role: "Admin" }
    ];

    for (const user of seedUsers) {
      const hash = await bcrypt.hash(user.password, 10);
      const createdAt = new Date().toISOString();
      await run(
        "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
        [user.username, hash, user.role || "Agent", createdAt]
      );
    }
  }

  const configRow = await get("SELECT json FROM site_config WHERE id = 1");
  if (!configRow) {
    const seedConfig = fs.existsSync(SEED_PATH)
      ? JSON.parse(fs.readFileSync(SEED_PATH, "utf8"))?.siteConfig
      : null;
    const config = seedConfig || DEFAULT_CONFIG;
    await run("INSERT INTO site_config (id, json) VALUES (1, ?)", [
      JSON.stringify(config)
    ]);
  }
}

app.use(express.json({ limit: "10mb" }));
app.use(
  session({
    secret: process.env.SESSION_SECRET || "cia-secret",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
  })
);

app.use((req, res, next) => {
  if (
    req.path.startsWith("/data") ||
    req.path.startsWith("/server") ||
    req.path.startsWith("/node_modules")
  ) {
    return res.status(404).end();
  }
  next();
});
app.use(express.static(ROOT));

async function requireAuth(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "غير مصرح." });
  }
  const user = await get("SELECT id, username, role FROM users WHERE id = ?", [
    req.session.userId
  ]);
  if (!user) {
    req.session.destroy(() => {});
    return res.status(401).json({ error: "غير مصرح." });
  }
  req.user = user;
  next();
}

function requireAdmin(req, res, next) {
  if (req.user.role !== "Owner" && req.user.role !== "Admin") {
    return res.status(403).json({ error: "صلاحيات غير كافية." });
  }
  next();
}

app.post("/api/register", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: "الرجاء إدخال الاسم وكلمة المرور." });
  }
  const existing = await get("SELECT id FROM users WHERE username = ?", [
    username
  ]);
  if (existing) {
    return res.status(409).json({ error: "هذا المستخدم موجود مسبقًا." });
  }
  const hash = await bcrypt.hash(password, 10);
  const createdAt = new Date().toISOString();
  const result = await run(
    "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
    [username, hash, "Agent", createdAt]
  );
  await run(
    "INSERT INTO logs (user_id, ts, action, detail) VALUES (?, ?, ?, ?)",
    [result.lastID, createdAt, "register", "Account created"]
  );
  res.json({ ok: true });
});

app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: "الرجاء إدخال الاسم وكلمة المرور." });
  }
  const user = await get(
    "SELECT id, username, password_hash, role FROM users WHERE username = ?",
    [username]
  );
  if (!user) {
    return res.status(401).json({ error: "بيانات الدخول غير صحيحة." });
  }
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) {
    return res.status(401).json({ error: "بيانات الدخول غير صحيحة." });
  }
  req.session.userId = user.id;
  const now = new Date().toISOString();
  await run("UPDATE users SET last_login_at = ? WHERE id = ?", [now, user.id]);
  await run(
    "INSERT INTO logs (user_id, ts, action, detail) VALUES (?, ?, ?, ?)",
    [user.id, now, "login", "Login success"]
  );
  res.json({ ok: true });
});

app.post("/api/logout", requireAuth, async (req, res) => {
  req.session.destroy(() => {});
  res.json({ ok: true });
});

app.get("/api/me", requireAuth, async (req, res) => {
  res.json({ user: req.user });
});

app.get("/api/bootstrap", requireAuth, async (req, res) => {
  const configRow = await get("SELECT json FROM site_config WHERE id = 1");
  const siteConfig = configRow ? JSON.parse(configRow.json) : DEFAULT_CONFIG;
  res.json({ user: req.user, siteConfig });
});

app.get("/api/config", requireAuth, async (req, res) => {
  const configRow = await get("SELECT json FROM site_config WHERE id = 1");
  const siteConfig = configRow ? JSON.parse(configRow.json) : DEFAULT_CONFIG;
  res.json(siteConfig);
});

app.post("/api/config", requireAuth, requireAdmin, async (req, res) => {
  const patch = req.body?.patch || {};
  const configRow = await get("SELECT json FROM site_config WHERE id = 1");
  const current = configRow ? JSON.parse(configRow.json) : DEFAULT_CONFIG;
  const next = {
    ...current,
    ...patch,
    theme: { ...current.theme, ...(patch.theme || {}) },
    layout: { ...current.layout, ...(patch.layout || {}) },
    images: { ...current.images, ...(patch.images || {}) }
  };
  if (patch.hudPanels) next.hudPanels = patch.hudPanels;
  await run("UPDATE site_config SET json = ? WHERE id = 1", [
    JSON.stringify(next)
  ]);
  res.json(next);
});

app.post("/api/log", requireAuth, async (req, res) => {
  const { action, detail } = req.body || {};
  if (!action) return res.status(400).json({ error: "Missing action." });
  await run(
    "INSERT INTO logs (user_id, ts, action, detail) VALUES (?, ?, ?, ?)",
    [req.user.id, new Date().toISOString(), action, detail || ""]
  );
  res.json({ ok: true });
});

initDb()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("Failed to init database", err);
    process.exit(1);
  });
